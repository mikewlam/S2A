var sourceText;
var line = [];
var myFont;
var curIndex = 0;
var allwords, tokens;
var xpos, ypos, raise, yplay, size;
var language = [];


function preload (){
  sourceText=loadStrings('data/kafka.txt');
  Font1 = loadFont('data/ABCFavoritEduMono-Regular.otf');
  Font2 = loadFont('data/AUTHENTICSans-Condensed-90.otf');
 }
function setup() {
  createCanvas(windowWidth, windowHeight);
  translate(windowWidth/2, windowHeight/2);
  allwords = sourceText.join("\n");
  tokens = allwords.split(/\W+/);
  //frameRate(60);
  smooth();
}
function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}
function draw() {
  background(255, 200, 0);
  textFont (Font1);
  ypos = 90;
  xpos = 50;
  size = 80;
  raise=0;
  for (var j=0; j < language.length ; j++){
    language[j].display();
    //if (mouseIsPressed) {
    //background(255, 200, 0, 25);
    //language[j].move();
    //} 
  } for (var i=0; i < tokens.length; i++) {
      letter= tokens[i];
      var wordWidth = textWidth(tokens[i]);
      if (frameCount>1*i) {
        language.push(new Words (xpos, ypos-raise, letter, size));
        xpos+=wordWidth+50;
      if (ypos>windowHeight*0.75){
        raise+=90;
    } else if (xpos>windowWidth-150) {
        ypos+= 90;
        xpos = 50;
    } 
    }
  }
}

    
class Words {
  constructor (x, y, letter, size){
  this.x= xpos;
  this.y= ypos;
  this.letter= letter;
  this.textSize= size;
}
move () {
  this.x += int(random(-5, 5));
  this.y += int(random(-5, 5));
}  
display () {
    textSize(this.textSize);
    text(this.letter, this.x, this.y);
  }
}
